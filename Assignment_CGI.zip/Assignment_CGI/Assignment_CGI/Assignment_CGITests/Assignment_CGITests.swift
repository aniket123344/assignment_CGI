//
//  Assignment_CGITests.swift
//  Assignment_CGITests
//
//  Created by Aniket Shinde on 15/12/25.
//

import Testing
@testable import Assignment_CGI

struct Assignment_CGITests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
